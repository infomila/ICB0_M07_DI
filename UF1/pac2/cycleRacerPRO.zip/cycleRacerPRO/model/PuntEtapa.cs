﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace cycleRacerPRO
{
    public class PuntEtapa
    {
        public PuntEtapa( int pKm, int pAlcada, string pNom, TipusPuntEtapa pTipus)
        {
            Km = pKm;
            Alcada = pAlcada;
            Nom = pNom;
            Tipus = pTipus;
        }

        #region Propietats
        private int mKm;
        public int Km
        {
            get
            {
                return mKm;
            }

            set
            {
                mKm = Km;
            }
        }

        private int mAlcada;
        public int Alcada
        {
            get
            {
                return mAlcada;
            }

            set
            {
                mAlcada = value;
            }
        }

        private string mNom; 
        public string Nom
        {
            get
            {
                return mNom;
            }

            set
            {
                mNom = value;
            }
        }

        TipusPuntEtapa mTipus;
        public TipusPuntEtapa Tipus
        {
            get
            {
                return mTipus;
            }

            set
            {
                mTipus = value;
            }
        }
        #endregion
    }

}