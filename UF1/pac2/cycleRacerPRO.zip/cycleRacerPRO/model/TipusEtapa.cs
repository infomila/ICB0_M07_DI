﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Windows.UI.Xaml.Media.Imaging;

namespace cycleRacerPRO
{
    public class TipusEtapa
    {

        private static ObservableCollection<TipusEtapa> sTipusEtapes;
        public static ObservableCollection<TipusEtapa> GetTipusEtapes()
        {
            if (sTipusEtapes == null)
            {
                sTipusEtapes = new ObservableCollection<TipusEtapa>();
                //----------------------------------------------
                TipusEtapa t1 = new TipusEtapa(1, "Normal",
                    new BitmapImage(new Uri("ms-appx///Assets/tip_normal.png")));
                TipusEtapa t2 = new TipusEtapa(2, "Contra.Equips",
                    new BitmapImage(new Uri("ms-appx///Assets/tip_contra_equip.png")));
                TipusEtapa t3 = new TipusEtapa(3, "Contra.Individual",
                    new BitmapImage(new Uri("ms-appx///Assets/tip_contra_indi.png")));

                sTipusEtapes.Add(t1);
                sTipusEtapes.Add(t2);
                sTipusEtapes.Add(t3);

            }
            return sTipusEtapes;
        }





        public TipusEtapa( int pCodi, string pNom, BitmapImage pIcona)
        {
            mCodi= pCodi;
            mNom = pNom;
            mIcona = pIcona;
        }

        int mCodi;
        public int Codi
        {
            get
            {
                return mCodi;
            }
        }

        private string mNom;
        public string Nom
        {
            get
            {
                return mNom;
            }
        }
        BitmapImage mIcona;
        public BitmapImage Icona
        {
            get
            {
                return mIcona;
            }
        }
    }
}