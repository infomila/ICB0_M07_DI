﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Windows.UI.Xaml.Media.Imaging;

namespace cycleRacerPRO
{
    public class Etapa
    {

        private static ObservableCollection<Etapa> sEtapes;
        public static ObservableCollection<Etapa> GetEtapes()
        {
            if(sEtapes==null)
            {
                sEtapes = new ObservableCollection<Etapa>();
                ObservableCollection<TipusEtapa> tipusEtapes =
                    TipusEtapa.GetTipusEtapes();
                //----------------------------------------------
                Etapa e1 = new Etapa("Annecy-Chamonix",
                    "Lorem ipsum blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah ",
                    DateTime.Today, tipusEtapes[0],
                    new BitmapImage(new Uri("ms-appx///Assets/etapa1.png"))
                    );
                Etapa e2 = new Etapa("Chamonix-Nice",
                    "Lorem ipsum blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah ",
                    DateTime.Today.AddDays(1), tipusEtapes[1],
                    new BitmapImage(new Uri("ms-appx///Assets/etapa2.png"))
                    );
                Etapa e3 = new Etapa("Lion-Tolousse",
                    "Lorem ipsum blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah ",
                    DateTime.Today.AddDays(2), tipusEtapes[2],
                    new BitmapImage(new Uri("ms-appx///Assets/etapa3.png"))
                    );
                //-------------------------------------------------------
                //  Definició del perfil kilomètric de la primera etapa
                //-------------------------------------------------------
                /*
                    km, name, height, type
                    0, Annecy, 455m, 
                    25, Tailores, 457m,
                    40, Thones, 601m,
                    85, Cole de la Croix Fry, 1477, 
                    169, Chamonix ,943m,                 
                 */
                e1.Punts.Add( new PuntEtapa(0, 455, "Annecy", TipusPuntEtapa.NORMAL) );
                e1.Punts.Add(new PuntEtapa(25, 457, "Tailores", TipusPuntEtapa.SPRINT));
                e1.Punts.Add(new PuntEtapa(40, 601, "Thones", TipusPuntEtapa.NORMAL));
                e1.Punts.Add(new PuntEtapa(85, 1477, "Cole de la Croix Fry", TipusPuntEtapa.PORT_2));
                e1.Punts.Add(new PuntEtapa(169, 943, "Chamonix", TipusPuntEtapa.SPRINT));


                //-------------------------------------------------------
                sEtapes.Add(e1);
                sEtapes.Add(e2);
                sEtapes.Add(e3);
            }
            return sEtapes;
        }

        public Etapa( string pNom, string pDescripcio, DateTime pData, TipusEtapa pTipus, BitmapImage pFoto)
        {
            Nom = pNom;
            Descripcio = pDescripcio;
            Foto = pFoto;
            Data = pData;
            Tipus = pTipus;
            mPunts = new ObservableCollection<PuntEtapa>();
        }
        #region propietats
        string mNom;
        public string Nom
        {
            get
            {
                return mNom;
            }

            set
            {
                mNom = value;
            }
        }

        public int Km
        {
            get
            {
                throw new System.NotImplementedException();
            }

          }

        public string Descripcio
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        BitmapImage mFoto;
        public BitmapImage Foto
        {
            get
            {
                return mFoto;
            }

            set
            {
                mFoto = value;
            }
        }

        DateTime mData;
        public DateTime Data
        {
            get
            {
                return mData;
            }

            set
            {
                mData = value;
            }
        }

        TipusEtapa mTipus;
        public TipusEtapa Tipus
        {
            get
            {
                return mTipus;
            }

            set
            {
                mTipus = value;
            }
        }

        ObservableCollection<PuntEtapa> mPunts;
        public ObservableCollection<PuntEtapa> Punts
        {
            get
            {
                return mPunts;
            }
        }
        #endregion
    }




}